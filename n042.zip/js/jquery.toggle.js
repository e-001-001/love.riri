$(function() {

// メニューを開くボタンの動作
  var pull = $('#open');
  var menu = $('nav ul');
  var menuOpen = false;
  $(pull).on('click', function(e) {
    e.preventDefault();
    if (menuOpen) {
      menu.slideUp();
      menuOpen = false;
      pull.text('Open Menu'); //Open Menuは自由に変更可
    } else {
      menu.slideDown();
      menuOpen = true;
      pull.text('Close'); //Closeは自由に変更可
    }
    return false;
  });

// 小画面時にメニュー内リンクを押した場合、一度閉じる
// ページ内リンク用
  $('nav a').on('click', function() {
    (window.innerWidth ? window.innerWidth : $(window).width()) <= 600 && $('#open').click()
  });

// 小画面時にメニューを閉じてからリサイズするとメニューが表示されないのを防ぐ
  $(window).resize(function() {
    (window.innerWidth ? window.innerWidth : $(window).width()) > 600 && menu.is(':hidden') && menu.attr('style', '')
  });

// 画像リンクには装飾しない
  $('img').parent('a').addClass('bg-none');

});
